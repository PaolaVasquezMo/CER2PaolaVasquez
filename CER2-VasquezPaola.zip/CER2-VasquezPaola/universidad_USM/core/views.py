# core/views.py

# core/views.py

from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .forms import ProjectForm, IngresoDatosForm
from .models import Project, IngresoDatos

def index(request):
    return render(request, 'core/index.html')

@login_required
def project_list(request):
    if request.user.usuario.is_profesor:
        projects = Project.objects.filter(sponsored_by__isnull=True)
    else:
        projects = Project.objects.all()
    return render(request, 'core/project_list.html', {'projects': projects})

@login_required
def project_create(request):
    if request.method == 'POST':
        form = ProjectForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('project_list')
    else:
        form = ProjectForm()
    return render(request, 'core/project_form.html', {'form': form})

@login_required
def project_edit(request, pk):
    project = get_object_or_404(Project, pk=pk)
    if request.method == 'POST':
        form = ProjectForm(request.POST, instance=project)
        if form.is_valid():
            form.save()
            return redirect('project_list')
    else:
        form = ProjectForm(instance=project)
    return render(request, 'core/project_form.html', {'form': form})

@login_required
def ingreso_datos_create(request):
    if request.method == 'POST':
        form = IngresoDatosForm(request.POST)
        if form.is_valid():
            ingreso = form.save(commit=False)
            ingreso.estudiante = request.user.usuario.estudiante
            ingreso.save()
            return redirect('project_list')
    else:
        form = IngresoDatosForm()
    return render(request, 'core/ingreso_datos_form.html', {'form': form})

@login_required
def ingreso_datos_edit(request, pk):
    ingreso = get_object_or_404(IngresoDatos, pk=pk)
    if request.method == 'POST':
        form = IngresoDatosForm(request.POST, instance=ingreso)
        if form.is_valid():
            form.save()
            return redirect('project_list')
    else:
        form = IngresoDatosForm(instance=ingreso)
    return render(request, 'core/ingreso_datos_form.html', {'form': form})
