# core/forms.py

from django import forms
from .models import Project, IngresoDatos

class ProjectForm(forms.ModelForm):
    class Meta:
        model = Project
        fields = ['title', 'description', 'theme']

class IngresoDatosForm(forms.ModelForm):
    class Meta:
        model = IngresoDatos
        fields = ['titulo', 'descripcion']
