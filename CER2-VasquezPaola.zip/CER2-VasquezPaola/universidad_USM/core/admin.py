# core/admin.py

from django.contrib import admin
from .models import Project, Usuario, Profesor, Estudiante, IngresoDatos

admin.site.register(Project)
admin.site.register(Usuario)
admin.site.register(Profesor)
admin.site.register(Estudiante)
admin.site.register(IngresoDatos)
