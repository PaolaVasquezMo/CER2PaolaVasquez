# core/models.py

from django.db import models
from django.contrib.auth.models import User

class Project(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    theme = models.CharField(max_length=100)
    sponsored_by = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='sponsored_projects')

    def __str__(self):
        return self.title

class Usuario(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    is_profesor = models.BooleanField(default=False)
    is_estudiante = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username

class Profesor(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name='profesor')
    departamento = models.CharField(max_length=100)

    def __str__(self):
        return self.usuario.user.username

class Estudiante(models.Model):
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, related_name='estudiante')
    carrera = models.CharField(max_length=100)

    def __str__(self):
        return self.usuario.user.username

class IngresoDatos(models.Model):
    titulo = models.CharField(max_length=200)
    descripcion = models.TextField()
    estudiante = models.ForeignKey(Estudiante, on_delete=models.CASCADE, related_name='ingresos')

    def __str__(self):
        return self.titulo
